package com.musichub.geckoview;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.MediaSession;

import java.util.Collections;

public class MainActivity extends AppCompatActivity {
    private static final String TARGET_URL = "https://musichub.shares.zrok.io";
    private static final int REQUEST_POST_NOTIFICATIONS = 10;

    private GeckoRuntime runtime;
    private GeckoSession session;
    private MediaSession currentMediaSession;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        requestNotificationPermissionIfNeeded();

        Intent serviceIntent = new Intent(this, MusicPlaybackService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }

        runtime = GeckoRuntime.create(this);
        session = new GeckoSession(new GeckoSessionSettings.Builder()
                .userAgentOverride("MusicHubApp/1.2")
                .build());
        session.setMediaSessionDelegate(new MediaSession.Delegate() {
            @Override
            public void onActivated(@NonNull GeckoSession geckoSession, @NonNull MediaSession mediaSession) {
                currentMediaSession = mediaSession;
            }

            @Override
            public void onDeactivated(@NonNull GeckoSession geckoSession, @NonNull MediaSession mediaSession) {
                if (currentMediaSession == mediaSession) currentMediaSession = null;
            }

            @Override
            public void onMetadata(@NonNull GeckoSession geckoSession, @NonNull MediaSession mediaSession,
                                   @NonNull MediaSession.Metadata metadata) {
                currentMediaSession = mediaSession;
                MusicPlaybackService service = MusicPlaybackService.getInstance();
                if (service != null) {
                    service.updateMetadata(metadata.title != null ? metadata.title : "MusicHub",
                            metadata.artist != null ? metadata.artist : "", null);
                }
            }

            @Override
            public void onPlay(@NonNull GeckoSession geckoSession, @NonNull MediaSession mediaSession) {
                currentMediaSession = mediaSession;
                MusicPlaybackService service = MusicPlaybackService.getInstance();
                if (service != null) service.updatePlaybackState(true, 0L);
            }

            @Override
            public void onPause(@NonNull GeckoSession geckoSession, @NonNull MediaSession mediaSession) {
                currentMediaSession = mediaSession;
                MusicPlaybackService service = MusicPlaybackService.getInstance();
                if (service != null) service.updatePlaybackState(false, 0L);
            }

            @Override
            public void onStop(@NonNull GeckoSession geckoSession, @NonNull MediaSession mediaSession) {
                MusicPlaybackService service = MusicPlaybackService.getInstance();
                if (service != null) service.updatePlaybackState(false, 0L);
            }
        });

        session.open(runtime);
        GeckoView geckoView = findViewById(R.id.geckoview);
        geckoView.setSession(session);

        // This custom header only has an effect if the Zrok server explicitly supports it.
        session.load(new GeckoSession.Loader()
                .uri(TARGET_URL)
                .headerFilter(GeckoSession.HEADER_FILTER_UNRESTRICTED_UNSAFE)
                .additionalHeaders(Collections.singletonMap("skip_zrok_interstitial", "1")));

        MusicPlaybackService.setCommandListener(new MusicPlaybackService.PlaybackCommandListener() {
            @Override public void onPlay() { runOnUiThread(() -> { if (currentMediaSession != null) currentMediaSession.play(); }); }
            @Override public void onPause() { runOnUiThread(() -> { if (currentMediaSession != null) currentMediaSession.pause(); }); }
            @Override public void onNext() { runOnUiThread(() -> { if (currentMediaSession != null) currentMediaSession.nextTrack(); }); }
            @Override public void onPrevious() { runOnUiThread(() -> { if (currentMediaSession != null) currentMediaSession.previousTrack(); }); }
            @Override public void onSeek(long positionMs) { runOnUiThread(() -> { if (currentMediaSession != null) currentMediaSession.seekTo(positionMs / 1000.0, false); }); }
        });
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_POST_NOTIFICATIONS);
        }
    }

    @Override
    protected void onDestroy() {
        MusicPlaybackService.setCommandListener(null);
        if (session != null) {
            session.close();
            session = null;
        }
        super.onDestroy();
    }
}

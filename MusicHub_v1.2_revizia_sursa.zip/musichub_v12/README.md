# MusicHub Android v1.2 (GeckoView)

Android wrapper for `https://musichub.shares.zrok.io`, using GeckoView 121.

## Build

- JDK 17
- Gradle 8.4
- Android SDK Platform 34 and build tools installed

Run `gradle assembleDebug` from the project root. GitHub Actions builds the debug APK and uploads it as an artifact.

## Playback integration

The app maps GeckoView `MediaSession` events to an AndroidX `MediaSessionCompat` and a media-style foreground notification with Previous, Play/Pause, and Next controls. Actual background playback still depends on the website's media implementation and Android device behavior; validate on physical devices.

## Zrok custom header

The initial navigation sends `skip_zrok_interstitial: 1` using GeckoView's unrestricted header filter. This does not bypass authentication or security. It only works if the Zrok deployment explicitly recognizes this header; otherwise the interstitial remains. Remove the custom header if the server does not support it.

## Icon

`ic_launcher.xml` is a temporary vector placeholder. Replace it with the supplied MusicHub artwork before release if that image is available.

## Validation status

Source structure and build configuration have been normalized. This archive has not been compiled in this environment and no APK/device test is claimed. The CI workflow is included for verification.
